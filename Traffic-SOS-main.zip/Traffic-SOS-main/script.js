{/* <script>
        document.getElementById('fineForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission

            // Get form values
            var vehicleNumber = document.getElementById('vehicleNumber').value;
            var issueDate = document.getElementById('issueDate').value;
            var expiryDate = document.getElementById('expiryDate').value;
            var reason = document.getElementById('reason').value;
            var amount = document.getElementById('amount').value;

            // Display submitted details
            document.getElementById('vehicleNumberDisplay').textContent = 'Vehicle Number: ' + vehicleNumber;
            document.getElementById('issueDateDisplay').textContent = 'Issue Date: ' + issueDate;
            document.getElementById('expiryDateDisplay').textContent = 'Expiry Date: ' + expiryDate;
            document.getElementById('reasonDisplay').textContent = 'Reason: ' + reason;
            document.getElementById('amountDisplay').textContent = 'Amount: ' + amount;

            // Show the submitted details section
            document.getElementById('submittedDetails').style.display = 'block';
        });
    </script> */}